#include <iostream>

using namespace std;
#include <sstream>
/*
*=== Create classes Rectangle and RectangleArea===

The Rectangle class should have two data fields-width and height of int types.
The class should have display() method, to print the width and height of the
rectangle separated by space.

The RectangleArea class is derived from Rectangle class, i.e., it is the
sub-class of Rectangle class. The class should have read_input() method, to
read the values of width and height of the rectangle. The RectangleArea class
should also overload the display() method to print the area  of the rectangle.
*/

class Rectangle
{
public:
	int* height;
	int* width;

	Rectangle()
	{
		int height = 0;
		int width = 0;
		
	}
	~Rectangle()
	{

	}

	void display()
	{
		std::cout << *width << " " << *height << endl;
	}
};

class RectangleArea : public Rectangle
{

public:
	int w, h;
	RectangleArea()
	{}
	~RectangleArea()
	{
		// figure out how to delete pointer
		if (height && width != nullptr)
		{
			height = nullptr;
			width = nullptr;
		}
		delete width;
		delete height;
	}

	void read_input()
	{
		cin >> w;
		cin >> h;

		Rectangle:: width = &w;
		Rectangle::height = &h;
	}

	void display()
	{
		int area = 0;
		area = (*width) * (*height);

		std::cout << area;
	}

};


int main()
{
	/*
	* Declare a RectangleArea object
	*/
	RectangleArea r_area;

	/*
	* Read the width and height
	*/
	r_area.read_input();

	/*
	* Print the width and height
	*/
	r_area.Rectangle::display();

	/*
	* Print the area
	*/
	r_area.display();


	return 0;
}

