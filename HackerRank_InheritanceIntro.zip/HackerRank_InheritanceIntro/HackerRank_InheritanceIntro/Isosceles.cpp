#include "Isosceles.h"

Isosceles::Isosceles()
{

};

Isosceles::~Isosceles()
{

};

void Isosceles::printIsosceles()
{
	cout << "I am an isosceles triangle. \n";
}

void Isosceles::printAddIsoscelesMessage()
{
	printIsosceles();
	cout << "In an isosceles triangle two sides are equal. \n";
	PrintTriangleMessage();
}