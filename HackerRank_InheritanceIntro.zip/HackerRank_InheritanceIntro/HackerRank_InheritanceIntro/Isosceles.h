#ifndef _ISOSCELES_H_
#define _ISOSCELES_H_
#include "Triangle.h"


class Isosceles: public Triangle
{
public:
	Isosceles();
	~Isosceles();

	void printIsosceles();
	void printAddIsoscelesMessage();


};

#endif //Isosceles
