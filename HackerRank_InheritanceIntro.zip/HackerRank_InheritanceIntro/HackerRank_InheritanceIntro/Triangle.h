#ifndef _TRIANGLE_H_
#define _TRIANGLE_H_

#include <iostream>
using namespace std;

class Triangle
{
public:
	Triangle();
	~Triangle();
	void PrintTriangleMessage();
};
#endif // !_TRIANGLE_H_
