#include "Triangle.h"

Triangle::Triangle()
{
}

Triangle::~Triangle()
{

}

void Triangle::PrintTriangleMessage()
{
	cout << "I am a triangle. \n";
}
