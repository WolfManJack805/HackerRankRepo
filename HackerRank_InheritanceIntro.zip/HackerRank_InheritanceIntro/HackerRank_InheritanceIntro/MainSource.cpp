#include <iostream>
#include "Triangle.h"
#include "Isosceles.h"
using namespace std;

int main()
{	
	Isosceles i;
	// here is where the inheritance occurs. Note: that I only created one obj. @param i
	// i is calling the information from the Isosceles class to print the triangle message
	// my next step is to: write in the Isosceles class that will allow me to call- i am a (iso)triangle, new message, i am a triangle 
	i.printAddIsoscelesMessage();

	system("Pause");
	return 0;
}