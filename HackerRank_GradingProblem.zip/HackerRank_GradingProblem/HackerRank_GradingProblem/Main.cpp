/*
this code was succesful in submission. the environment below is a TEST ONLY envirnoment for the purposes of 
helping myself to learn to code in hacker rank without having to use the environment which is not successful for 
testing. by no way would i ever leave code like this.. this is for testing only!! good job on success
*/

//#include <bits/stdc++.h>
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

vector<int> gradingStudents(vector<int> grades);

int main()
{
	//ofstream fout(getenv("OUTPUTPATH"));

	int input;
	cin >> input;
	cin.ignore(INT32_MAX, '\n');

	vector<int> grades(input);

	for (int grades_itr = 0; grades_itr <= 5; grades_itr++) {
		int grades_item;
		cin >> grades_item;
		cin.ignore(numeric_limits<streamsize>::max(), '\n');

		grades[grades_itr] = grades_item;
	}

	vector<int> result = gradingStudents(grades);
	/*
	for (int result_itr = 0; result_itr < result.size(); result_itr++) {
		fout << result[result_itr];

		if (result_itr != result.size() - 1) {
		fout << "\n";
		}
	}

	fout << "\n";

	fout.close();
	*/
	system("pause");
	return 0;
}

/*
* Complete the gradingStudents function below.
*/
vector<int> gradingStudents(vector<int> grades) {
	/*
	* Write your code here.
	*/
	int currentGrade = 0;
	for (int i = 0; i < grades.size(); i++)
	{
		currentGrade = grades[i];
		
		if (currentGrade < 38)
		{
			grades[i] = currentGrade;
			cout << "Current grade stored: " << currentGrade << "at grades at i: " << grades[i] << endl;
		}
		else
		{
			if (currentGrade % 5 == 0)
			{
				// we current have a grade that is at a point of 5 or 0//
				grades[i] = currentGrade;
			}
			else
			{
				// hard number for use to represent that will only use a counter to change grade by
				//so many points// if 1,2,3,4 // will count until grade can be modded by 5// then that the new buffer
				//grade
				int bufferedGrade = 0;
				int gradeCounter = currentGrade;
				do
				{
					bufferedGrade = gradeCounter++;
				} while (bufferedGrade % 5 != 0);

				if (bufferedGrade - currentGrade < 3)
				{
					grades[i] = bufferedGrade;
				}
				else
				{
					grades[i] = currentGrade;
				}
			}
			cout << "Current buffered grade stored: " << currentGrade << "at grades at i: " << grades[i] << endl;
		}
	}
	//just incase i needed a new vector that will store prev. vec info
	//vector<int> newGrades(grades);
	return grades;

};