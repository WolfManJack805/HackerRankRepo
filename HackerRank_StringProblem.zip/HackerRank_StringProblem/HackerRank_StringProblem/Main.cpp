#include <iostream>
#include <string>
#include <vector>

using namespace std;
//creation of array with 1000 size
const int arrSize = 1000;

// implement 2 chars to house each input
//char charArrA[arrSize];
//char charArrB[arrSize];
//int stringLenA = 0;
//int stringLenB = 0;
//void AddCharToArray(char myChar);

int main()
{
	//create string @param a & @param b
	string a, b;
	// take in input @param a & param b
	cin >> a;
	cin >> b;
	
	//creation of array with 1000 size
	const int arrSize = 1000;

	// implement 2 chars to house each input
	char charArrA[arrSize];
	char charArrB[arrSize];

	for (int i = 0; i < a.length(); ++i)
	{
		charArrA[i] = a[i];
	}

	for (int j = 0; j < b.length(); ++j)
	{
		charArrB[j] = b[j];
	}
	
	//how many are in each array
	cout << a.length() << " " << b.length() << endl;

	// output each info in a and b 
	cout << a + b << endl;

	char temp = a[0];
	a[0] = b[0];
	b[0] = temp;

	cout << a << " " << b << endl;

	system("Pause");
	return 0;
}

/*
#include<iostream>
using std::cin;
using std::cout;
using std::endl;

void switchthese (char[], char[]);
int main()
{
char first[] = "sssssss";
char second[] = "aaa";

cout<<first<<endl;
cout<<second<<endl;

switchthese(first,second);

cout<<first<<endl;
cout<<second<<endl;
}

void switchthese(char first[], char second[])
{
int i = 0;
while(first[i]!='\0' && second[i]!='\0')
{
char temp=first[i];
first[i]=second[i];
second[i]=temp;
i++;
}
}
*/