#include <iostream>
#include <string>
using namespace std;

class Student
{
private:
	int age = 0;
	string frstName;
	string lastName;
	// int standard;
public:

	int getAge()
	{
		return age;
	}

	void setAge(int ageInput)
	{
		age += ageInput;
	}

	string getFirstName()
	{
		return frstName;
	}

	void setFirstName(string frstNameInput)
	{
		frstName = frstNameInput;
	}

	string getLastName()
	{
		return lastName;
	}

	void setLastName(string lastNameInput)
	{
		lastName = lastNameInput;
	}

	/*
	
	int getStandard()
	{
		return standard;
	}

	void setStandard(int standardInput)
	{
		standard += standardInput
	}
	*/

};

int main()
{
	return 0;
}