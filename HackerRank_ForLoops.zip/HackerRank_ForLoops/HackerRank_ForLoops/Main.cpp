#include <iostream>
#include <vector>
using namespace std;

int main() {
	// Complete the code.
	int firstInput = 0;
	int secondInput = 0;
	vector<int> numsInput;

	cin >> firstInput;
	cin >> secondInput;

	for (int i = firstInput; i <= secondInput; ++i)
	{
		numsInput.emplace_back(i);
	}

	int evalInput = 0;
	for (int i = 0; i < numsInput.size(); ++i)
	{
		evalInput = numsInput[i];
		if (evalInput >= 10)
		{
			if (evalInput % 2 == 0)
			{
				cout << "even" << endl;
			}
			else
			{
				cout << "odd" << endl;
			}
		}
		else if (evalInput <= 9)
		{
			evalInput = numsInput[i];
			switch (evalInput)
			{
			case 1:
				cout << "one" << endl;
				break;
			case 2:
				cout << "two" << endl;
				break;
			case 3:
				cout << "three" << endl;
				break;
			case 4:
				cout << "four" << endl;
				break;
			case 5:
				cout << "five" << endl;
				break;
			case 6:
				cout << "six" << endl;
				break;
			case 7:
				cout << "seven" << endl;
				break;
			case 8:
				cout << "eight" << endl;
				break;
			case 9:
				cout << "nine" << endl;
				break;
			default:
				break;
			}
		}

	}
	return 0;
}