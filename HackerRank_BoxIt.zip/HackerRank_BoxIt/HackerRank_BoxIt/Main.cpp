#include <iostream>
using namespace std;


//Implement the class Box
// The class should have the following functions :
class Box
{
	int l, b, h;
public:

	// Constructors:
	Box(){
		l, b, h = 0;
	};

	Box(int len, int br, int height)
	{
		h = height;
		b = br;
		l = len;
	};

	Box(const Box &B)
	{
		l = B.l;
		b = B.b;
		h = B.h;
	};

	~Box()
	{

	};

	// int getLength(); // Return box's length
	int getLength(){
		return l;
	}

	// int getBreadth (); // Return box's breadth
	int getBredth(){
		return b;
	}

	// int getHeight ();  //Return box's height
	int getHeight() {
		return h;
	}

	// long long CalculateVolume(); // Return the volume of the box
	long long CalculateVolume(){
		return (long long)l * h * b;
	}


	//bool operator<(Box& b)
	friend bool operator< (const Box& A, const Box& B)
	{
		if (  A.l < B.l ||  A.b < B.b && A.l == B.l || B.h < A.h && A.b == B.b && A.l == B.l)
			return true;
		else
			return false;
	}

	//Overload operator << as specified (for class Box)
	//ostream& operator<<(ostream& out, Box& B)
	friend ostream& operator<< (ostream& os, const Box& B)
	{
		os << B.l << " " << B.b << " " << B.h;
		return os;
	}

};


void check2()
{
	int n;
	cin>>n;
	Box temp;
	for(int i=0;i<n;i++)
	{
		int type;
		cin>>type;

		if(type ==1)
		{
			cout<<temp<<endl;
		}

		if(type == 2)
		{
			int l,b,h;
			cin>>l>>b>>h;
			Box NewBox(l,b,h);
			temp=NewBox;
			cout<<temp<<endl;
		}

		if(type==3)
		{
			int l,b,h;
			cin>>l>>b>>h;
			Box NewBox(l,b,h);
			if(NewBox<temp)
			{
				cout<<"Lesser\n";
			}
			else
			{
				cout<<"Greater\n";
			}
		}

		if(type==4)
		{
			cout<<temp.CalculateVolume()<<endl;
		}

		if(type==5)
		{
			Box NewBox(temp);
			cout<<NewBox<<endl;
		}
	}
}

int main()
{
	check2();
	return 0;
}


