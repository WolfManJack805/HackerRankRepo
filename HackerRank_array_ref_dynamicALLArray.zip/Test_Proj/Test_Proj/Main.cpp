#include <iostream>
#include <array>
using namespace std;

int input = 0;

int main()
{
	cout << "Please input 5 numbers: ";
	int arrSizeInput;
	cin >> arrSizeInput;
	cin.ignore(INT32_MAX, '\n');
	cin.clear();
	
	int *arr = new int[arrSizeInput];

	for (int i = 0; i < arrSizeInput; ++i)
	{
		cin >> input;
		cin.ignore(INT32_MAX, '\n');
		cin.clear();
		arr[i] = input;
	}

	for (int j = 0; j < arrSizeInput; ++j)
	{
		cout << arr[j] << " ";
	}

	system("pause");
	delete[] arr;
	return 0;
}

/*
my submission

#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

int input = 0;

int main() {

	Enter your code here. Read input from STDIN. Print output to STDOUT
	int arrSize;
	cin >> arrSize;
	int* arr = new int[arrSize];

	for (int i = 0; i < arrSize; ++i)
	{
		cin >> arr[i];
	}

	for (int j = arrSize - 1; j >= 0; --j)
	{
		cout << arr[j] << " ";
	}

	delete[] arr;
	arr = nullptr;
	return 0;
}

*/