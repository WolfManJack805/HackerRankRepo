#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<int> v;

int main()
{
	/* Enter your code here. Read input from STDIN. Print output to STDOUT */
	int size = 0;
	cout << "Plese input your vector size:";
	cin >> size;
	
	//Size:  int size=v.size();

	for (int i = 0; i < size; ++i)
	{
		int input;
		cout << "Please input your vector numbers:";
		cin >> input;

		// Pushing int into vector: v.push_back(x);(where x is an integer.The size
		// increases by 1 after this.)
		v.push_back(input);
	}

	cout << "Our vector size is: " << v.size() << endl;

	for (int j = 0; j < v.size(); ++j)
	{
		sort(v.begin(), v.end());
		cout << v[j] << " ";
	}
	
	// You are given N integers.Sort the N integers and print the sorted order.
	//Store N the integers in a vector.
	//Vectors are sequence containers representing arrays that can change in N size.

	//Declaration: vector<int>v; (creates an empty vector of integers)

	

	// vector sort : sort(v.begin(),v.end()); (Will sort all the elements in the
	// vector)

	// Poping last element from vector: v.pop_back(); (After this the size
	// decreases by 1)

	// input format: The first line of the input contains  N where N is the number
	// of integers. The next line contains  integers.
	//Constraints
	/*
		1 <= N <= 10^5
		1 <= V(i) <= 10^9, where V(i) is the iTH int in the vector
	*/
	//  where is the integer in the vector.

	//    Output Format
	//Print the integers in the sorted order one by one in a single line
	//followed by a space.

	/// Sample Input

	//5 
	//1 6 10 8 4 
	//Sample Output
	// 1 4 6 8 10
	system("Pause");
	return 0;
}