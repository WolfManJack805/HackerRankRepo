
//#include <bits/stdc++.h>
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

/*
* Complete the timeConversion function below.
*/
string timeConversion(string s) {
	/*
	* Write your code here.
	//HH:MM:SSAM or HH:MM:SSPM
	//0123456789
	*/

	string hour = s.substr(0, 2);
	string min = s.substr(3, 2);
	string seconds = s.substr(6, 2);
	string dayOrNight = s.substr(8, 2);

	cout << "Here is what is stored in my substring shown with and endline: ";
	cout << hour << endl << min << endl << seconds << endl << dayOrNight << endl;
	if (dayOrNight == "PM" || dayOrNight == "pm")
	{
		if (hour == "01")
		{
			hour = "13";
		}
		else if (hour == "02")
		{
			hour = "14";
		}
		else if (hour == "03")
		{
			hour = "15";
		}
		else if (hour == "04")
		{
			hour = "16";
		}
		else if (hour == "05")
		{
			hour = "17";
		}
		else if (hour == "06")
		{
			hour = "18";
		}
		else if (hour == "07")
		{
			hour = "19";
		}
		else if (hour == "08")
		{
			hour = "20";
		}
		else if (hour == "09")
		{
			hour = "21";
		}
		else if (hour == "10")
		{
			hour = "22";
		}
		else if (hour == "11")
		{
			hour = "23";
		}
		else if (hour == "12")
		{
			hour = "00";
		}

		s = hour + min + seconds;
		return s;
	}

	return s;

}

int main()
{

	string s;
	getline(cin, s);

	string result = timeConversion(s);

	cout << result << "\n";
	system("pause");

	return 0;
}